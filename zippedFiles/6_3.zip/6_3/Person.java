public class Person {
    private String name;

    Person(String name) {
        this.name = name;
    }

    public String getPerson() {
        return name;
    }
}
